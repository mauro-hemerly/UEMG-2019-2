package atributoestatico;

/**
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class UsaAtributoEstatico {
    public static void main(String[] args) {
        // Usando construtor
        AtributoEstatico ae1 = AtributoEstatico.criaInstancia( 100,200 );  
        
        
        // Usando métod fábrica
        AtributoEstatico ae2 = AtributoEstatico.criaInstancia( 300,400 );
        System.out.println("ae1: " + "i = " + ae1.getI() + "    j = " + ae1.getJ() );
        System.out.println("ae2: " + "i = " + ae2.getI() + "    j = " + ae2.getJ() );
        
        
        System.out.println("\n==============================\n");
        
        AtributoEstatico ae3 = AtributoEstatico.criaInstancia( 500,600 );
        AtributoEstatico ae4 = AtributoEstatico.criaInstancia( 700,800 );
          
        System.out.println("ae3: " + "i = " + ae3.getI() + "    j = " + ae3.getJ() );
        System.out.println("ae4: " + "i = " + ae4.getI() + "    j = " + ae4.getJ() );
        
    }
}
