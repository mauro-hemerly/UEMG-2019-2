package atributoestatico;

/**
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class AtributoEstatico {

    static int i;
    private int j;
    private static int nroInstancias = 0;

    private AtributoEstatico(int i, int j) {
        this.i = i;
        this.j = j;
        //nroInstancias++;
    }

    // Método fábrica
    public static AtributoEstatico criaInstancia(int i, int j) {
        if (nroInstancias < 10) {
            nroInstancias++;
            return  new AtributoEstatico(i, j);
        }
        else {
            return null;
        }
    }

    public static int getI() {
        return i;
    }

    public int getJ() {
        return j;
    }

}
