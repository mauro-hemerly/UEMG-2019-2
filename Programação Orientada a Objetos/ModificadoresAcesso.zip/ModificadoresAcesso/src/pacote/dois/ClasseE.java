 
package pacote.dois;

import pacote.Um.ClasseA;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseE {
    public void metodoE() {
        ClasseA a1 = new ClasseA();
        a1.x = a1.x + 100;
     //   a1.y = a1.y + 200; 
     //   a1.z = a1.z + 300;
     //   a1.w = a1.w + 400;
    }
    
    
    
}
