 
package pacote.Um;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseB extends ClasseA {
    public void metodoB() {
        ClasseA a1 = new ClasseA();
        a1.x = a1.x + 100;
        y = y + 200;
        a1.z = a1.z + 300;
     //   a1.w = a1.w + 400;
    }
}
