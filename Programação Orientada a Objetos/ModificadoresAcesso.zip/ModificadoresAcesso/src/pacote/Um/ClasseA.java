 
package pacote.Um;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class ClasseA {
   public       int x = 11;
   protected    int y = 22;
                int z = 33;
   private      int w = 44;
   
    public void metodoA() {
        
       x = x + 100;
        y = y + 200; 
        z = z + 300;
       w = w + 400;
    }
   
   
} 
