 
package pontoflutuante;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class PontoFlutuanteSolucao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double x = 0.0;
        
        while ( Math.abs(x-1.0) > 0.0000000001 ) {
            System.out.println("x = " + x);
            
            try { Thread.sleep (1000); } catch (InterruptedException ex) {}   // aguarde alguns segundos
            
            x = x + 0.1;
        }
        
         System.out.println("Saída do while: x = " + x);
         
         int xx = 8;
         
         System.out.println(xx++*10);
    }
    
}
