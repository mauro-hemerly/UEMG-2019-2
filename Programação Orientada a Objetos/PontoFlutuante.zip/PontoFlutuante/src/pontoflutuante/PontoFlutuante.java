 
package pontoflutuante;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class PontoFlutuante {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double x = 0.0;
        
        while (x != 1.0) {
            System.out.println("x = " + x);
            
            try { Thread.sleep (1000); } catch (InterruptedException ex) {}   // aguarde alguns segundos
            x = x + 0.1;
        }
    }
    
}
