 
package atribuicao;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
class Letter {
    char c;
}
