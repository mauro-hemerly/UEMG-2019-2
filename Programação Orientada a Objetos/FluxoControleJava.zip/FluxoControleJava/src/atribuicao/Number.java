
package atribuicao;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
class Number {
    int i;
}
