
package OperadoresRelacionais;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class Value {
    int i;
}
