 
package metodoestatico;

/**
 *
 * @author Mauro Hemerly (Hämmerli) Gazzani
 */
public class MetodoEstatico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          
          System.out.println(Math.log10(100));
          
          naoEstatico();
          
          MetodoEstatico me = new MetodoEstatico();
          
          me.naoEstatico();
          
          
    }
    
    
    public static void naoEstatico() {
        
    }
    
}
